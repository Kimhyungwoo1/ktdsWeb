package com.melon.admin.user.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.melon.admin.authorization.biz.AuthorizationBiz;
import com.melon.admin.authorization.biz.AuthorizationBizImpl;
import com.melon.admin.authorization.vo.AuthorizationSearchVO;
import com.melon.admin.user.biz.UserBiz;
import com.melon.admin.user.biz.UserBizImpl;
import com.melon.admin.user.vo.UserSearchVO;
import com.melon.admin.user.vo.UserVO;

public class UserServiceImpl implements UserService{
	
	private UserBiz userBiz;
	private AuthorizationBiz authorizationBiz;
	
	public UserServiceImpl () {
		userBiz = new UserBizImpl();
		authorizationBiz = new AuthorizationBizImpl();
	}

	@Override
	public List<UserVO> getAllUser(UserSearchVO userSearchVO) {
		return userBiz.getAllUser(userSearchVO);
	}

	@Override
	public UserVO getOneUser(UserVO userVO) {
		return userBiz.getOneUser(userVO);
	}

	@Override
	public UserVO getOneUser(String userId) {
		return userBiz.getOneUser(userId);
	}
	
	@Override
	public Map<String, Object> getOneUserWithAuthorization(String userId) {
		
		AuthorizationSearchVO authorizationSearchVO = new AuthorizationSearchVO();
		authorizationSearchVO.getPager().setPageNumber(0);
		
		Map<String, Object> user = new HashMap<String, Object>();
		user.put("user", userBiz.getOneUser(userId));
		user.put("authorizations", authorizationBiz.getAllAuthorization(authorizationSearchVO));
		
		return null;
	}
	
	@Override
	public boolean registNewUser(UserVO userVO) {
		return userBiz.registNewUser(userVO);
	}

	@Override
	public boolean updateUser(UserVO userVO) {
		return userBiz.updateUser(userVO);
	}

	@Override
	public boolean deleteOneUser(String userId) {
		return userBiz.deleteOneUser(userId);
	}

}
